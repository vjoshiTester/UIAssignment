$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("GoogleSearch.feature");
formatter.feature({
  "line": 1,
  "name": "Google Search",
  "description": "Description : Google search a criteria, move to amazon and purchase",
  "id": "google-search",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 5,
  "name": "Amazon search and buy",
  "description": "",
  "id": "google-search;amazon-search-and-buy",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 4,
      "name": "@GoogleSearch"
    }
  ]
});
formatter.step({
  "line": 6,
  "name": "I launch browser \"chrome\" in \"GUI\" and open \"\u003cURL\u003e\"",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "I search the  \"\u003cCriteria\u003e\" on the \u0027Search\u0027 page",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "I note down the search results",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "I click on Amazon link",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "I click on All button on search and select \"\u003cCategory\u003e\" as category",
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "I search Product \"\u003cProductSearch\u003e\" from the search bar",
  "keyword": "And "
});
formatter.step({
  "line": 12,
  "name": "I apply \"\u003cLowRange\u003e\" to \"\u003cHighRange\u003e\" as filter range",
  "keyword": "And "
});
formatter.step({
  "line": 13,
  "name": "Validate the products displayed on the screen are within \"\u003cLowRange\u003e\" to \"\u003cHighRange\u003e\" range",
  "keyword": "And "
});
formatter.examples({
  "line": 15,
  "name": "below data set for data driven",
  "description": "",
  "id": "google-search;amazon-search-and-buy;below-data-set-for-data-driven",
  "rows": [
    {
      "cells": [
        "URL",
        "LowRange",
        "HighRange",
        "ProductSearch",
        "Category",
        "Criteria"
      ],
      "line": 16,
      "id": "google-search;amazon-search-and-buy;below-data-set-for-data-driven;1"
    },
    {
      "cells": [
        "GOOGLE",
        "30000",
        "50000",
        "Dell Computers",
        "Electronics",
        "Amazon"
      ],
      "line": 17,
      "id": "google-search;amazon-search-and-buy;below-data-set-for-data-driven;2"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 92365200,
  "status": "passed"
});
formatter.before({
  "duration": 13300,
  "status": "passed"
});
formatter.before({
  "duration": 10618300,
  "status": "passed"
});
formatter.before({
  "duration": 17000,
  "status": "passed"
});
formatter.before({
  "duration": 3661500,
  "status": "passed"
});
formatter.before({
  "duration": 10900,
  "status": "passed"
});
formatter.scenario({
  "line": 17,
  "name": "Amazon search and buy",
  "description": "",
  "id": "google-search;amazon-search-and-buy;below-data-set-for-data-driven;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 4,
      "name": "@GoogleSearch"
    }
  ]
});
formatter.step({
  "line": 6,
  "name": "I launch browser \"chrome\" in \"GUI\" and open \"GOOGLE\"",
  "matchedColumns": [
    0
  ],
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "I search the  \"Amazon\" on the \u0027Search\u0027 page",
  "matchedColumns": [
    5
  ],
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "I note down the search results",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "I click on Amazon link",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "I click on All button on search and select \"Electronics\" as category",
  "matchedColumns": [
    4
  ],
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "I search Product \"Dell Computers\" from the search bar",
  "matchedColumns": [
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 12,
  "name": "I apply \"30000\" to \"50000\" as filter range",
  "matchedColumns": [
    1,
    2
  ],
  "keyword": "And "
});
formatter.step({
  "line": 13,
  "name": "Validate the products displayed on the screen are within \"30000\" to \"50000\" range",
  "matchedColumns": [
    1,
    2
  ],
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "chrome",
      "offset": 18
    },
    {
      "val": "GUI",
      "offset": 30
    },
    {
      "val": "GOOGLE",
      "offset": 45
    }
  ],
  "location": "GeneralSteps.iLaunchBrowserAndOpenURLWithHeadless(String,String,String)"
});
formatter.result({
  "duration": 8087079000,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Amazon",
      "offset": 15
    }
  ],
  "location": "GeneralSteps.searchOnThePage(String)"
});
formatter.result({
  "duration": 16022429700,
  "status": "passed"
});
formatter.match({
  "location": "GeneralSteps.noteDownSearchResuls()"
});
formatter.result({
  "duration": 2214866400,
  "status": "passed"
});
formatter.match({
  "location": "GeneralSteps.clickTheLink()"
});
formatter.result({
  "duration": 13573750700,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Electronics",
      "offset": 44
    }
  ],
  "location": "GeneralSteps.selectCategory(String)"
});
formatter.result({
  "duration": 5207770200,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Dell Computers",
      "offset": 18
    }
  ],
  "location": "GeneralSteps.searchProduct(String)"
});
formatter.result({
  "duration": 11163346500,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "30000",
      "offset": 9
    },
    {
      "val": "50000",
      "offset": 20
    }
  ],
  "location": "GeneralSteps.applyRange(String,String)"
});
formatter.result({
  "duration": 13467153300,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "30000",
      "offset": 58
    },
    {
      "val": "50000",
      "offset": 69
    }
  ],
  "location": "GeneralSteps.validateProductRange(String,String)"
});
formatter.result({
  "duration": 1040676600,
  "status": "passed"
});
formatter.after({
  "duration": 28900,
  "status": "passed"
});
formatter.after({
  "duration": 144400,
  "status": "passed"
});
formatter.after({
  "duration": 865878200,
  "status": "passed"
});
});